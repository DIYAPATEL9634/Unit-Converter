def meters_to_feet(meters):
  return meters * 3.28084

def feet_to_meters(feet):
  return feet / 3.28084

def inches_to_meters(inches):
  return inches * 0.0254

def meters_to_inches(meters):
  return meters / 0.0254

def inches_to_feet(inches):
  return inches / 12

def feet_to_inches(feet):
  return feet * 12

def main():
  print("Welcome to the Length Unit Converter!")
  print("1. Meters to Feet")
  print("2. Feet to Meters")
  print("3. Inches to Meters")
  print("4. Meters to Inches")
  print("5. Inches to Feet")
  print("6. Feet to Inches")

  choice = int(input("Enter your choice (1/2/3/4/5/6): "))

  if choice == 1:
      meters = float(input("Enter length in meters: "))
      print("Length in feet:", meters_to_feet(meters))
  elif choice == 2:
      feet = float(input("Enter length in feet: "))
      print("Length in meters:", feet_to_meters(feet))
  elif choice == 3:
      inches = float(input("Enter length in inches: "))
      print("Length in meters:", inches_to_meters(inches))
  elif choice == 4:
      meters = float(input("Enter length in meters: "))
      print("Length in inches:", meters_to_inches(meters))
  elif choice == 5:
      inches = float(input("Enter length in inches: "))
      print("Length in feet:", inches_to_feet(inches))
  elif choice == 6:
      feet = float(input("Enter length in feet: "))
      print("Length in inches:", feet_to_inches(feet))
  else:
      print("Invalid choice!")

if __name__ == "__main__":
  main()
